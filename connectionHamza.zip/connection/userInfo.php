<!DOCTYPE html>
<html> 
	<head> 
		<title> Connections - USER PROFILE </title>
		<meta charset="UTF-8">
		<link href="style1.css" rel="stylesheet" type="text/css">
	</head> 
	<body> 
	
	<?php 
		session_start();
		if(isset($_SESSION['varname'])){
			$email = $_SESSION['varname'];
		
			$con = mysqli_connect('localhost', 'root', '7860', 'conDB1');
			$result = mysqli_query($con, "SELECT * FROM regtable1");
		
			while ($row = mysqli_fetch_array($result)){
				if ($row['email'] == $email)
				{
					$name = $row['name'];
					$pic = $row['image'];
				}	
			}	
		}

		else{
			echo "<script> alert('User is logged out! Kindly login to access this page.')</script>";
			echo "<script> location.href='index.php' </script>";
		}
	?>
	
	<div class="container1">
		<div id="header">
			<div id="logo">
				<p><b id="logo_text">CONNECTIONS</b> <br> <span id="getConnected"><i>Get Connected</i></span></p>
			</div>
			<div class="assignmentBy"><span>SOCIAL NETWORKING WEBSITE<br></span> <i><br> -- HAMZA ZEB</i></div>
		</div>
		
		<div class="userInfoDiv">
		
			<div class="actions">
				<div id="login1">ACTIONS</div>
				<ul>
					<li><a href="#">Your Profile</a></li>
					<li><a href="sendMsg.php">Sent Message</a></li>
					<li><a href="received.php">Inbox</a></li>
					<li><a href="sentMessages.php">Outbox</a></li>
					<li><a href="logout.php">Signout</a></li>
				</ul>
			</div>
				
			<div class="userInfo">
				<div id="login1">USER PROFILE <?php echo "<span style='float:right; margin-right:10px;'>User Email: $email </span>"; ?></div>
				 <div class="userImg">
				
					<?php echo "<img class = 'userImage' src='images/".$pic."' >"; ?>
				</div>
				<div class="userData"><br>
					<span class="usrName"> 
					<?php
						echo $name;
					?>
					</span>
					<br><br>
					<span>
					<?php 
						echo $email ;
					?>
					</span>
				</div>	
			</div>
			
		</div>
		
		<div class="footer" >
			<p>&copy All Right Reserved</p>
		</div>
	</div>

	</body> 
</html> 