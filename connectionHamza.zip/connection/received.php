<!DOCTYPE html>
<html> 
	<head> 
		<title> Connections - USER PROFILE </title>
		<meta charset="UTF-8">
		<link href="style1.css" rel="stylesheet" type="text/css">
	</head> 
	<body> 
	
	<?php 
		session_start();
		if(isset($_SESSION['varname'])){
			$email = $_SESSION['varname'];
			}
		$userflg = false;
		
		$con = mysqli_connect('localhost', 'root', '7860', 'conDB1');
		$result = mysqli_query($con, "SELECT * FROM messages");
		
		$msgarr = [];
		$earr = [];
		
		while ($row = mysqli_fetch_array($result)){
			if ($row['sentTo'] == $email){
				$earr[] = $row['sentFrom'];
				$msgarr[] = $row['message'];
			}
		}	
		
	?>
	
	<div class="container1">
		<div id="header">
			<div id="logo">
				<p><b id="logo_text">CONNECTIONS</b> <br> <span id="getConnected"><i>Get Connected</i></span></p>
			</div>
			<div class="assignmentBy"><span>SOCIAL NETWORKING WEBSITE<br></span> <i><br> -- HAMZA ZEB</i></div>
		</div>
		
		<div class="userInfoDiv">
		
			<div class="actions">
				<div id="login1">ACTIONS</div>
				<ul>
					<li><a href="userInfo.php">Your Profile</a></li>
					<li><a href="sendMsg.php">Sent Message</a></li>
					<li><a href="#">Inbox</a></li>
					<li><a href="sentMessages.php">Outbox</a></li>
					<li><a href="logout.php">Signout</a></li>
				</ul>
			</div>
			
			<div class="userInfo">
				<div id="login1">RECEIVED MESSAGES <?php echo "<span style='float:right; margin-right:10px;'> User Email: $email </span>"; ?></div>
				
				
				<div class="recMsg">
				<?php 
				$i = 0;
				foreach($earr as $arr){
					echo "<b>FROM:</b> $arr <br>"; 
					echo "<b>TO:</b> $email <br>";
					echo "<b>MESSAGE:</b> $msgarr[$i] <br>";
					echo "<br><hr style='width: 80%;'><br>";
					$i++;
				}
				?>
				</div>
			</div>
			<div class="footer" >
				<p>&copy All Right Reserved</p>
			</div>
		</div>
		
	</div>
		
		
	</div>

	</body> 
</html> 