<?php

session_start();
//header('location:index.php');

$con = mysqli_connect('localhost', 'root', '7860');
mysqli_select_db($con, 'conDB1');

$name = $_POST['user'];
$pass = $_POST['password'];
$email = $_POST['email'];
$image = $_FILES['image']['name'];

$target = "images/".basename($image);

$s = "select * from regtable1 where email = '$email'";

$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);

if($num == 1){
	echo "<script> alert('This Email is already registered! Use another Email Address.')</script>";
	echo "<script> location.href='index.php' </script>";
}else{
	if(move_uploaded_file($_FILES['image']['tmp_name'], $target)){
	$reg = "insert into regtable1(name, email, password, image) values ('$name', '$email', '$pass', '$image')";
	mysqli_query($con, $reg);
	
	echo "<script> alert('Registration Successful! Click OK to login')</script>";
	echo "<script> location.href='index.php' </script>";
	//echo " Registration Successful: ($email)";
}}

?>