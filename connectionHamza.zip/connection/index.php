<!DOCTYPE html>
<html> 
	<head> 
		<title> Connections - HOME </title>
		<meta charset="UTF-8">
		<link href="style1.css" rel="stylesheet" type="text/css">
	</head> 
	<body> 
	<div id="container">
		<div id="header">
			<div id="logo">
				<p><b id="logo_text">CONNECTIONS</b> <br> <span id="getConnected"><i>Get Connected</i></span></p>
			</div>
			<div class="assignmentBy"><span>SOCIAL NETWORKING WEBSITE<br></span> <i><br> -- HAMZA ZEB</i></div>
		</div>
		
		<div class="homeInfoDiv">
			<div id="login">
				<div id="login1">USER LOGIN</div>
				<form action="validation.php" method="post">
					<br>
					Email       
					<input type="email" name="email" required>
					<br><br>
					Password       
					<input type="password" name="password" required>
					
					<span class="loginButton"><input type="submit" value="LOGIN"></span>
				</form>
			</div>
			<div id="signup">
				<div id="login1">USER REGISTRATION</div>
				<form action="registration.php" method="post" enctype="multipart/form-data">
					<br>
					Your Full Name       
					<input type="text" name="user" required>
					<br><br>
					Your Email Address      
					<input type="email" name="email" required>
					<br><br>
					New Password 
					<input type="password" name="password" required>
					<br><br>
					Your Picture       
					<input type="file" name="image" id="image">
					
					<span class="loginButton"><input type="submit" name="upload" value="SIGN UP"></span>
				</form>
			</div>
		</div>
		<div class="footer" >
			<p>&copy All Right Reserved</p>
		</div>
	</div>
	</body> 
</html> 
