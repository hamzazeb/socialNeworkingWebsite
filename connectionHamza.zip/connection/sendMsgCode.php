<?php

session_start();

$recEmail = $_POST['recEmail'];
$yourMsg = $_POST['yourMsg'];

$userflg = false;

		if(isset($_SESSION['varname'])){
		
			$email = $_SESSION['varname'];
		
			$con = mysqli_connect('localhost', 'root', '7860', 'conDB1');
			$result = mysqli_query($con, "SELECT * FROM regtable1");
		
			while ($row = mysqli_fetch_array($result)){
				if ($row['email'] == $recEmail){
					$userflg = true;
				}	
			}	

			if ($userflg == true){
				$reg = "insert into messages(sentFrom, sentTo, message) values ('$email', '$recEmail', '$yourMsg')";
				mysqli_query($con, $reg);
				
				echo "<script> alert('Message sent successfully! From ($email) to ($recEmail).')</script>";
				mysqli_close($con);
				echo "<script> location.href='sendMsg.php' </script>";
			}else{
				echo "<script> alert('No user registered with this Email address!')</script>";
				mysqli_close($con);
				echo "<script> location.href='sendMsg.php' </script>";
			}
		}else{
			echo "<script> alert('User is logged out! Kindly login to access this page.')</script>";
			echo "<script> location.href='index.php' </script>";
		}

		

?>