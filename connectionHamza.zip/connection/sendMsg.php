<!DOCTYPE html>
<html> 
	<head> 
		<title> Connections - SEND MESSAGE</title>
		<meta charset="UTF-8">
		<link href="style1.css" rel="stylesheet" type="text/css">
	</head> 
	<body> 
	<?php 
		session_start();
		if(isset($_SESSION['varname'])){
			$email = $_SESSION['varname'];
			}
	?>
	<div class="container1">
		<div id="header">
			<div id="logo">
				<p><b id="logo_text">CONNECTIONS</b> <br> <span id="getConnected"><i>Get Connected</i></span></p>
			</div>
			<div class="assignmentBy"><span>SOCIAL NETWORKING WEBSITE<br></span> <i><br> -- HAMZA ZEB</i></div>
			
		</div>
		<div class="sendMsgDiv">
			<div class="actions">
				<div id="login1">ACTIONS</div>
				<ul>
					<li><a href="userInfo.php">Your Profile</a></li>
					<li><a href="#">Sent Message</a></li>
					<li><a href="received.php">Inbox</a></li>
					<li><a href="sentMessages.php">Outbox</a></li>
					<li><a href="logout.php">Signout</a></li>
				</ul>
			</div>
		<form action="sendMsgCode.php" method="post" enctype="multipart/form-data">
			<div class="sendMsg">
				<div id="login1">SEND YOUR MESSAGE <?php echo "<span style='float:right; margin-right:10px;'> User Email: $email </span>"; ?></div>
				<div class="emailAndMsg"><br>
					<b class="emailField">Receiver Email:</b> <input type="email" class="recEmail" name="recEmail" id="recEmail" placeholder="Enter Receiver's Email Address" required><br><br>
					<b class="msgField">Your Message:</b> <br> <textarea id="yourMsg" name="yourMsg" placeholder="Enter Your Message Here >>" required></textarea><br>
					<span class="sendMsgButton"><input type="submit" name="sendMsg" value="SEND MESSAGE"></span>
				</div>
			</div>
		</form>	
		</div>
		<div class="footer" >
			<p>&copy All Right Reserved</p>
		</div>
	</div>
	</body> 
</html> 
