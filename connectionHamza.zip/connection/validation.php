<?php

session_start();

$con = mysqli_connect('localhost', 'root', '7860');
mysqli_select_db($con, 'conDB1');

$pass = $_POST['password'];
$email = $_POST['email'];


$s = "select * from regtable1 where email = '$email' && password = '$pass'";

$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);

if($num == 1){
	$_SESSION['varname'] = $email;
	header('location:userInfo.php');
}else{
	echo "<script> alert('Username or Password is incorrect!')</script>";
	echo "<script> location.href='index.php' </script>";
	//header('location:index.php');
}

?>